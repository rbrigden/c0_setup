#ifndef __BARE_H__
#define __BARE_H__

#define C0_RUNTIME_IMPLEMENTS_LENGTH
#include <c0runtime.h>

// For slight speed gain, inline:
#define c0_string_fromliteral(s) (s)

#endif // __BARE_H__
